export const siteConfig = {
  site_name: "YTube Player",
  home_title: "YTube Player - Watch and Share Videos",
  home_description: "Discover and watch amazing videos on YTube Player. Share your favorites with friends and family.",
  home_robots: "index, follow",
  watch_title: "{videoTitle} - YTube Player",
  watch_desc: "Watch {videoTitle} on YTube Player. Enjoy high-quality videos and discover more content.",
  watch_robots: "index, follow",
  search_title: "Search results for '{query}' - YTube Player",
  search_description:
    "Explore video results for '{query}' on YTube Player. Find your favorite content and discover new videos.",
  search_robots: "noindex, follow",
  download_title: "Download {videoTitle} - YTube Player",
  download_description: "Download {videoTitle} from YTube Player. Save your favorite videos for offline viewing.",
  download_robots: "noindex, nofollow",
}

