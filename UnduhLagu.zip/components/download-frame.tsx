interface DownloadFrameProps {
  videoId: string
}

export default function DownloadFrame({ videoId }: DownloadFrameProps) {
  return (
    <div className="space-y-4">
      <iframe
        allowFullScreen={true}
        frameBorder="0"
        height="60"
        scrolling="no"
        src={`https://musicyt.click/mp33.php?id=${videoId}`}
        width="100%"
      />
      <iframe
        allowFullScreen={true}
        frameBorder="0"
        height="60"
        scrolling="no"
        src={`https://mp4api.ytjar.info/?id=${videoId}`}
        width="100%"
      />
    </div>
  )
}

