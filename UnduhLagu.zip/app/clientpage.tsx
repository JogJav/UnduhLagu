"use client"
import { useState, useEffect, Suspense } from "react"
import { useSearchParams } from "next/navigation"
import Header from "@/components/header"
import VideoGrid from "@/components/video-grid"
import type { VideoItem } from "@/lib/types"
import ClientLoading from "./clientloading"

// Create a separate component that uses useSearchParams
function VideoContent() {
  const [videos, setVideos] = useState<VideoItem[]>([])
  const [loading, setLoading] = useState(true)
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const searchParams = useSearchParams()
  const query = searchParams.get("q")

  useEffect(() => {
    if (query) {
      handleSearch(query)
    } else {
      fetchVideos()
    }
  }, [query, page])

  const fetchVideos = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/list?page=${page}&per_page=12`)
      const data = await response.json()

      if (data.status === 200) {
        // Filter out any videos related to Washington, D.C. (client-side backup filter)
        const filteredVideos = data.result.filter(
          (video: VideoItem) =>
            !video.title.toLowerCase().includes("washington") &&
            !video.title.toLowerCase().includes("d.c.") &&
            !(video.description && video.description.toLowerCase().includes("washington")) &&
            !(video.description && video.description.toLowerCase().includes("d.c.")),
        )
        setVideos(filteredVideos)
        setTotalPages(Math.ceil(data.total / data.per_page))
      }
    } catch (error) {
      console.error("Error fetching videos:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = async (searchQuery: string) => {
    if (!searchQuery.trim()) return

    try {
      setLoading(true)
      const response = await fetch(`/api/search?q=${encodeURIComponent(searchQuery)}`)
      const data = await response.json()

      if (data.status === 200) {
        // Filter out any videos related to Washington, D.C. (client-side backup filter)
        const filteredVideos = data.result.filter(
          (video: VideoItem) =>
            !video.title.toLowerCase().includes("washington") &&
            !video.title.toLowerCase().includes("d.c.") &&
            !(video.description && video.description.toLowerCase().includes("washington")) &&
            !(video.description && video.description.toLowerCase().includes("d.c.")),
        )
        setVideos(filteredVideos)
        setTotalPages(1) // Search results don't have pagination in this implementation
      }
    } catch (error) {
      console.error("Error searching videos:", error)
    } finally {
      setLoading(false)
    }
  }

  const handlePrevPage = () => {
    if (page > 1) setPage(page - 1)
  }

  const handleNextPage = () => {
    if (page < totalPages) setPage(page + 1)
  }

  return (
    <main className="container mx-auto px-4 py-8">
      {query && (
        <h1 className="text-2xl font-bold mb-6">
          Search results for: <span className="text-primary">{query}</span>
        </h1>
      )}

      <VideoGrid videos={videos} loading={loading} />

      {!query && videos.length > 0 && (
        <div className="flex justify-center mt-8 space-x-2">
          <button
            onClick={handlePrevPage}
            disabled={page === 1}
            className="px-4 py-2 bg-background border border-input rounded-md shadow-sm text-sm font-medium hover:bg-accent hover:text-accent-foreground disabled:opacity-50"
          >
            Previous
          </button>
          <span className="px-4 py-2 bg-background border border-input rounded-md shadow-sm text-sm font-medium">
            Page {page} of {totalPages}
          </span>
          <button
            onClick={handleNextPage}
            disabled={page === totalPages}
            className="px-4 py-2 bg-background border border-input rounded-md shadow-sm text-sm font-medium hover:bg-accent hover:text-accent-foreground disabled:opacity-50"
          >
            Next
          </button>
        </div>
      )}
    </main>
  )
}

export default function ClientHomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      <Suspense fallback={<ClientLoading />}>
        <VideoContent />
      </Suspense>

      <footer className="border-t bg-background mt-auto">
        <div className="container mx-auto px-4 py-4 text-center text-muted-foreground">
          &copy; {new Date().getFullYear()} UnduhLagu
        </div>
      </footer>
    </div>
  )
}

