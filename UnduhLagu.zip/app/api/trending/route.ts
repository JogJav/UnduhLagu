import { type NextRequest, NextResponse } from "next/server"
import { getTrendingVideos } from "@/lib/youtube"

export async function GET(request: NextRequest) {
  try {
    const trendingData = await getTrendingVideos()
    return NextResponse.json(trendingData)
  } catch (error) {
    console.error("Error getting trending videos:", error)
    return NextResponse.json({ status: 500, msg: "Internal server error" }, { status: 500 })
  }
}

