"use client"
import { useState, useEffect } from "react"
import Header from "@/components/header"
import VideoGrid from "@/components/video-grid"
import type { VideoItem } from "@/lib/types"

export default function TrendingPage() {
  const [videos, setVideos] = useState<VideoItem[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchTrendingVideos = async () => {
      try {
        setLoading(true)
        const response = await fetch(`/api/trending`)
        const data = await response.json()

        if (data.status === 200) {
          // Filter out any videos related to Washington, D.C. (client-side backup filter)
          const filteredVideos = data.result.filter(
            (video: VideoItem) =>
              !video.title.toLowerCase().includes("washington") &&
              !video.title.toLowerCase().includes("d.c.") &&
              !(video.description && video.description.toLowerCase().includes("washington")) &&
              !(video.description && video.description.toLowerCase().includes("d.c.")),
          )
          setVideos(filteredVideos)
        }
      } catch (error) {
        console.error("Error fetching trending videos:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchTrendingVideos()
  }, [])

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-6">Trending Musik Indonesia</h1>
        <VideoGrid videos={videos} loading={loading} />
      </main>

      <footer className="border-t bg-background mt-auto">
        <div className="container mx-auto px-4 py-4 text-center text-muted-foreground">
          &copy; {new Date().getFullYear()} YouTube Clone
        </div>
      </footer>
    </div>
  )
}

